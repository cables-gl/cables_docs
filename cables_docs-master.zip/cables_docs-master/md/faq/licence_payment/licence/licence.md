### What license do i need to use cables?

There is no need to buy a license when using cables. Simply register, login and start patching.

Everything needed to run a cables patch is licensed under the [MIT License](https://opensource.org/licenses/MIT)

Every export you create of a cables patch will contain information about the licenses of other included libraries (which are all compatible with MIT, if you didn't add then on your own)
