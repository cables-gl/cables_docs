# Communication

In this chapter you will learn how cables can communicate with the outside world.

__TOC__
