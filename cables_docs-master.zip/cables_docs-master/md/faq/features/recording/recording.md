# Screenshots and Video recording
## How can I save images/textures/screenshots/videos of my patch?
We have ops for this!
For images, screenshots - check out the [Download Texture Operator](https://cables.gl/op/Ops.Gl.DownloadTexture_v2) . This will let you save your texture on demand and in custom resolutions. You can learn all about it in our [video tutorial here](https://www.youtube.com/watch?v=YFvVsEPirRc).

For live recording videos of your patch straight from the editor - try our [Media Recorder Operator](https://cables.gl/op/Ops.Gl.MediaRecorder). You can also find the [video tutorial for it here.](https://www.youtube.com/watch?v=zWfwC-GH7qk)
