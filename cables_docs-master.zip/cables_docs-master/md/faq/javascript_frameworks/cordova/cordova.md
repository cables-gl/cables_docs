# cordova / phonegap

To get you started running your patches natively on mobile phones, we created a skeleton to integrate cables into
[apache cordova](https://cordova.apache.org/), try it here:

https://github.com/cables-gl/cables-phonegap-skeleton

Please [let us know](https://discord.gg/cablesgl) if/once this needs an update or does not work anymore.
