# Intermediate

__TOC__

For more learning resources with image compositions and post processing there are 2 videos over on our [youtube channel](https://www.youtube.com/channel/UC7IRYQBFbt1KX4YmhBuIbhA)

[Post processing tutorial for beginners](https://youtu.be/x2jKZgmFVq4)
[Post processing effects part 2](https://youtu.be/r4_EHvNTntE)
