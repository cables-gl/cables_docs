# electron

The easiest way of getting cables.gl patches running in electron, is to use the [exe export](../../../4_export_embed/dev_embed/export_exe/export_exe). If you need more control
over all the steps in building, you might want to check out "da playa":

https://github.com/cables-gl/cables-daplaya

Please [let us know](https://discord.gg/cablesgl) if/once this needs an update or does not work anymore.
