# vuejs

Find a repository with a vue-component to load one or more patches in your [vue](https://vuejs.org/) app here:

https://github.com/undev-studio/cables_vue/

Please [let us know](https://discord.gg/cablesgl) if/once this needs an update or does not work anymore.
