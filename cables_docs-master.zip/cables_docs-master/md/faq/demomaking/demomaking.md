# How to make demoscene demos with cables.gl

- A youtube tutorial video: https://www.youtube.com/watch?v=v4rYqHuT-0E&t=5972s

- Please tag your demo with "demoscene" !

## Demo Templates

Check out these patches, copy them and make them your demo:

- https://cables.gl/p/C0ZBZ9 Simple Demo Template
- https://cables.gl/p/OkHGVg Advanced Demo Template

## Published Demos on Cables.gl

There are published demo patches on cables.gl

- e.g. check the demoscene tag: https://cables.gl/tag/demoscene

## links

- cables demos on pouet: https://www.pouet.net/lists.php?which=107
- cables demos youtube playlist: https://www.youtube.com/playlist?list=PLYimpE2xWgBuyCiSTlyhMpC4to9uXrmYe

