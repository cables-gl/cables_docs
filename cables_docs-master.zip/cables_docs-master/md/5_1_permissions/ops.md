# Permissions

As cables is not only a tool to use on your own, but also a place on the web to share  and collaborate
on patches, there is several levels of permissions. These decide on who can view, use or edit things.

All of these things are only of your concern when working on [cables.gl](https://cables.gl). Your exported patches
contain no permission checks or talk to our servers at all.

Check the following sections for a deeper understanding on how collaboration works in cables:

__TOC__

