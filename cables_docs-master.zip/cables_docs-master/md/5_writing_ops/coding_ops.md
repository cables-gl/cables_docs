# Coding Ops

learn how to write your own operators!
We also have a [youtube playlist](https://www.youtube.com/watch?v=vJ47_rYdezU&list=PLYimpE2xWgBvKQg65p9q5sa2jJaHGO7Ka) to help you get started. 

__TOC__
