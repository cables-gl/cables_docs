#### Does cables support midi and OSC?

Yes. We have detailed tutorials showing you how to set this up. Look for the playlist called **Midi and OSC** on our [youtube channel](https://www.youtube.com/channel/UC7IRYQBFbt1KX4YmhBuIbhA) 

A full list of all the midi ops can be found at our [midi section](https://cables.gl/ops/Ops.Devices.Midi)

To get started with **OSC** inside cables follow this tutorial over on our [youtube channel](https://www.youtube.com/watch?v=1cIhDfrHM74)
