# Will there be support for (animated) GIFs?

There will be no support for animated GIFs, because there is no direct javascript access to single frames in an animated GIF.

Please use Video Files or operators like ImageSequenceAnim,TextureArray etc.

