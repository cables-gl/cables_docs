### Will I have to pay for it in the future?

All the major features of cables will always be free for use by everyone. There are no plans on restricting use to
any current or future new ops or features to something like "pro" or "premium" users.

You can pay for additional storage space for your assets, increasing the upload size or the number of exports per day. 
Rest assured that the free version of cables.gl will be absolutely usable at all times. All "limits" are bound to support-levels,
check them out on [Patreon](https://www.patreon.com/cables_gl) if you are above the limit at any point in time.


### Is there a way to support cables development somehow?

First of all: spread the word. Use it! Give feedback! Join our [Discord](https://discord.gg/cablesgl) and [Github Discussions](https://github.com/cables-gl/cables_docs/discussions)!

If you are looking for more options, [this FAQ](../../features/support/support) might help you.


