# Patch Permissions

A cables patch can have different states and also different people working on the project. Here is a rundown of the
different levels of permission cables offers to teams and individuals. Check out [all the different options](../../5_1_permissions/1_patches/patches).
