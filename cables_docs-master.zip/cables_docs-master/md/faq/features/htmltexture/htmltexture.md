# Can i use a website as a texture?

Sadly, there is no way to render a website or an iframe as a texture on the clientside.
