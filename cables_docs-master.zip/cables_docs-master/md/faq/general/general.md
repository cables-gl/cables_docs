# General questions

#### How do i create an account?

- Head on over to https://cables.gl/ and hit the register button. Respond to the e-mail authentification and then your account will be active.

#### What should I do If I have problems creating an account?
- Contact us at hi@undev.de and we'll fix it asap.

#### Do I have to install cables?

- cables runs exclusively in the browser so there's nothing to install ;-)

#### What intellectual rights do I have for the work that I create?
- You own all the intellectual rights to to the work you create with cables. We also have a list of Creative commons licenses that you can use if you make a patch public.

#### Do I have to give credit to cables gl with any of my published works for myself and or with clients?

- No, but we would really like it if you do! We love to hear it when cables gets used in real world projects.

#### I found a bug! What should I do now?

- [Post a bug report](https://github.com/cables-gl/cables_docs/issues), or describe the issue on the [forums](https://github.com/cables-gl/cables_docs/discussions/122)
