#### Why doesn't the DownloadTexture op work on iOS?

iOS cannot automatically save files. The user has to long press an image and select “save to camera roll”. This is
intended behaviour on iOS and cannot be overwritten, so this will probably not supported by the DownloadTexture op.
