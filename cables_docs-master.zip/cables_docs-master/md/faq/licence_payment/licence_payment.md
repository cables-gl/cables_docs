# Licenses and payment

all the legal fun!

__TOC__
