# How to optimize cables patches with the Profiler

The profiler can be found under **Tools > Profile**. It can analyze how much the CPU is being used by Ops in your patch.

It also gives more information about different parts of your patch (e.g. subpatches).
