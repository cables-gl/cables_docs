# Working With Audio

In this section of the documentation, we are going to dive into how to use audio files within cables. Please keep in mind that the operators are subject to change in the future. We will try to keep the documentation as up to date as possible but if you find outdated parts or explanations that don't hold true anymore, 
us on Discord](https://discord.gg/cablesgl).

__TOC__
